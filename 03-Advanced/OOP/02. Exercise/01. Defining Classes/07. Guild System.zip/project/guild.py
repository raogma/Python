class Guild:
    def __init__(self, name):
        self.name = name
        self.players = []

    def assign_player(self, player):
        if player.guild != 'Unaffiliated' and player.guild != self.name:
            return f"Player {player.name} is in another guild."
        if player in self.players:
            return f"Player {player.name} is already in the guild."
        player.guild = self.name
        self.players.append(player)
        return f"Welcome player {player.name} to the guild {self.name}"

    def kick_player(self, player_name):
        for object in self.players:
            if object.name == player_name:
                object.guild = 'Unaffiliated'
                self.players.remove(object)
                return f"Player {player_name} has been removed from the guild."
        return f"Player {player_name} is not in the guild."

    def guild_info(self):
        res = f'Guild: {self.name}\n'
        for object in self.players:
            res += f'{object.player_info()}'
        return res