class Trainer:
    def __init__(self, name: str):
        self.name = name
        self.pokemon = []

    def add_pokemon(self, pokemon):
        if pokemon not in self.pokemon:
            self.pokemon.append(pokemon)
            return f"Caught {pokemon.pokemon_details()}"
        return "This pokemon is already caught"

    def release_pokemon(self, pokemon_name: str):
        for element in self.pokemon:
            if element.name == pokemon_name:
                self.pokemon.remove(element)
                return f"You have released {pokemon_name}"
        return "Pokemon is not caught"

    def trainer_data(self):
        res = str()
        res += f'Pokemon Trainer {self.name}\n'
        res += f'Pokemon count {len(self.pokemon)}\n'
        for element in self.pokemon:
            res += f'- {element.pokemon_details()}\n'
        return res